import verifyLoginOTPService from '../services/verifyLoginOTP.service.js';

const verifyLoginOTP = async (req, res, next) => {
    try {

        const data = await verifyLoginOTPService(req.body);

        res.status(200).json(data);

    } catch (error) {
        next(error);
    }
};

export default verifyLoginOTP;
