import sendLoginOTPService from '../services/sendLoginOTP.service.js';

const sendLoginOTP = async (req, res, next) => {
    try {

        const data = await sendLoginOTPService(req.body);

        res.status(200).json(data);

    } catch (error) {
        next(error);
    }
};

export default sendLoginOTP;
