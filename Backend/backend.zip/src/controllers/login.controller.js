import loginService from '../services/login.service.js';

const login = async (req, res, next) => {
    try {

        const data = await loginService(req.body);

        res.status(200).json({
            success: true,
            data
        });

    } catch (error) {
        next(error);
    }
};

export default login;
