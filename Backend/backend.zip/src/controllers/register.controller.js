import registerService from '../services/register.service.js';

const register = async (req, res, next) => {
    try {

        const data = await registerService(req.body);

        res.status(201).json({
            success: true,
            data
        });

    } catch (error) {
        next(error);
    }
};

export default register;
