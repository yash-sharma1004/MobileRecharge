import mongoose from 'mongoose';

const otpSchema = new mongoose.Schema({
    identifier: String,
    otpHash: String,
    purpose: String,
    expiresAt: Date
}, {
    timestamps: true
});

const Otp = mongoose.model('Otp', otpSchema);

export default Otp;
