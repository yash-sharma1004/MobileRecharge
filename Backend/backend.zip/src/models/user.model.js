import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const userSchema = new mongoose.Schema({
    name: String,
    email: String,
    mobile: String,
    passwordHash: String
}, {
    timestamps: true
});

userSchema.pre('save', async function(next) {

    if (!this.isModified('passwordHash')) {
        return next();
    }

    this.passwordHash = await bcrypt.hash(
        this.passwordHash,
        10
    );

    next();
});

userSchema.methods.comparePassword = async function(password) {
    return bcrypt.compare(password, this.passwordHash);
};

const User = mongoose.model('User', userSchema);

export default User;
