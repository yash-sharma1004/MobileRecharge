import express from 'express';

import register from '../controllers/register.controller.js';
import login from '../controllers/login.controller.js';
import sendLoginOTP from '../controllers/sendLoginOTP.controller.js';
import verifyLoginOTP from '../controllers/verifyLoginOTP.controller.js';

const router = express.Router();

router.post('/register', register);

router.post('/login', login);

router.post('/login-otp/send', sendLoginOTP);

router.post('/login-otp/send', verifyLoginOTP);

export default router;
