import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT),
    secure: false,
    auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
    }
});

const sendOTPEmail = async (to, otp) => {

    await transporter.sendMail({
        from: process.env.EMAIL_FROM,
        to,
        subject: 'OTP Verification',
        html: `
            <div>
                <h2>Your OTP</h2>
                <h1>${otp}</h1>
                <p>Valid for 5 minutes</p>
            </div>
        `
    });
};

export default sendOTPEmail;
