import bcrypt from 'bcryptjs';

const verifyOTP = async (otp, hash) => {
    return bcrypt.compare(otp, hash);
};

export default verifyOTP;
