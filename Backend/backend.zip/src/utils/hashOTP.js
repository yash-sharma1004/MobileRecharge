import bcrypt from 'bcryptjs';

const hashOTP = async (otp) => {
    return bcrypt.hash(otp, 10);
};

export default hashOTP;
