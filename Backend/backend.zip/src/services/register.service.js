import User from '../models/user.model.js';
import AppError from '../utils/AppError.js';
import generateToken from '../utils/generateToken.js';

const registerService = async (userData) => {

    const existingEmail = await User.findOne({
        email: userData.email
    });

    if (existingEmail) {
        throw new AppError('Email already exists', 400);
    }

    const existingMobile = await User.findOne({
        mobile: userData.mobile
    });

    if (existingMobile) {
        throw new AppError('Mobile already exists', 400);
    }

    const user = await User.create({
        name: userData.name,
        email: userData.email,
        mobile: userData.mobile,
        passwordHash: userData.password
    });

    const token = generateToken(user._id);

    return {
        user,
        token
    };
};

export default registerService;
