import Otp from '../models/otp.model.js';
import User from '../models/user.model.js';
import AppError from '../utils/AppError.js';
import verifyOTP from '../utils/verifyOTP.js';
import generateToken from '../utils/generateToken.js';

const verifyLoginOTPService = async ({ identifier, otp }) => {

    const otpRecord = await Otp.findOne({
        identifier,
        purpose: 'LOGIN'
    });

    if (!otpRecord) {
        throw new AppError('OTP expired', 400);
    }

    if (otpRecord.expiresAt < new Date()) {

        await Otp.deleteOne({
            _id: otpRecord._id
        });

        throw new AppError('OTP expired', 400);
    }

    const isValid = await verifyOTP(
        otp,
        otpRecord.otpHash
    );

    if (!isValid) {
        throw new AppError('Invalid OTP', 400);
    }

    const user = await User.findOne({
        $or: [
            { email: identifier },
            { mobile: identifier }
        ]
    });

    const token = generateToken(user._id);

    await Otp.deleteOne({
        _id: otpRecord._id
    });

    return {
        user,
        token
    };
};

export default verifyLoginOTPService;
