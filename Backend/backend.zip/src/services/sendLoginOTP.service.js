import User from '../models/user.model.js';
import Otp from '../models/otp.model.js';
import AppError from '../utils/AppError.js';
import generateOTP from '../utils/generateOTP.js';
import hashOTP from '../utils/hashOTP.js';
import sendOTPEmail from '../utils/sendOTPEmail.js';

const sendLoginOTPService = async ({ identifier }) => {

    const user = await User.findOne({
        $or: [
            { email: identifier },
            { mobile: identifier }
        ]
    });

    if (!user) {
        throw new AppError('User not found', 404);
    }

    await Otp.deleteMany({
        identifier,
        purpose: 'LOGIN'
    });

    const otp = generateOTP();

    const otpHash = await hashOTP(otp);

    await sendOTPEmail(
        identifier,
        otp,
        'LOGIN'
    );

    await Otp.create({
        identifier,
        otpHash,
        purpose: 'LOGIN',
        expiresAt: new Date(Date.now() + 5 * 60 * 1000)
    });

    return {
        message: 'OTP sent successfully'
    };
};

export default sendLoginOTPService;
