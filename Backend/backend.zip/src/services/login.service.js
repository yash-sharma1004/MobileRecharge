import User from '../models/user.model.js';
import AppError from '../utils/AppError.js';
import generateToken from '../utils/generateToken.js';

const loginService = async ({ identifier, password }) => {

    const user = await User.findOne({
        $or: [
            { email: identifier },
            { mobile: identifier }
        ]
    });

    if (!user) {
        throw new AppError('Invalid credentials', 401);
    }

    const isValid = await user.comparePassword(password);

    if (!isValid) {
        throw new AppError('Invalid credentials', 401);
    }

    const token = generateToken(user._id);

    return {
        user,
        token
    };
};

export default loginService;
